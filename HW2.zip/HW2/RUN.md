## Question 1.1
For this question you can run bc1_1.py as it is without changing.

## Question 1.2
For this question you can run bc1_2.py as it is without changing to get all performance metrics for each task.

## Question 1.3
For this question you can run bc1_3.py as it is without changing anything; it will create the graph automatically.

## Question 2.1
For this question you can run dagger2_1.py as it is without changing anything; it will create the graph automatically. 