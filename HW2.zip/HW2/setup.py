# setup.py
from setuptools import setup

setup(
    name='cs558',
    version='0.1.0',
    packages=['cs558'],
)